from django.apps import AppConfig


class ClimateConfig(AppConfig):
    name = 'Climate'
